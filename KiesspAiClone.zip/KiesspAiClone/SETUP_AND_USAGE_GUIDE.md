# Voice Transformer - Setup and Usage Guide

This guide provides step-by-step instructions for setting up and using the Voice Transformer application, along with all necessary terminal commands.

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Installation](#installation)
3. [Running the Server](#running-the-server)
4. [Web Interface](#web-interface)
5. [Client Application](#client-application)
6. [Voice Transformation Features](#voice-transformation-features)
7. [Troubleshooting](#troubleshooting)

## System Requirements

### Server Requirements
- Python 3.8 or newer
- Sufficient disk space for dependencies (at least 1GB)
- RAM: 4GB minimum, 8GB recommended

### Client Requirements (Windows Application)
- Windows 10 or newer
- Python 3.8 or newer (for running from source)
- Virtual audio device (e.g., VB-Cable)

## Installation

### Server Installation Commands

```bash
# Clone the repository (replace with actual repository URL)
git clone https://github.com/yourusername/voice-transformer.git
cd voice-transformer

# Create and activate a virtual environment (recommended)
python -m venv venv
# On Windows
venv\Scripts\activate
# On macOS/Linux
source venv/bin/activate

# Install dependencies from dependencies.txt
pip install -r dependencies.txt
```

### Virtual Audio Device Installation

For the client application to work correctly with other applications (Zoom, Discord, etc.), you need to install a virtual audio device:

1. Download VB-Cable from [VB-Audio Website](https://vb-audio.com/Cable/)
2. Extract and run the installer as administrator
3. Restart your computer after installation

## Running the Server

### Development Mode

```bash
# Run the server in development mode
python run.py
```

### Production Mode with Gunicorn

```bash
# Run in production mode
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

### Persistence and Keeping the Server Running

If you want to keep the server running after closing the terminal:

```bash
# Install screen (on Linux)
sudo apt-get install screen

# Start a new screen session
screen -S voice_transformer

# Run the server
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app

# Detach from screen session (keeps server running)
# Press Ctrl+A, then D

# To reattach to the session later
screen -r voice_transformer
```

## Web Interface

Once the server is running, you can access the web interface by navigating to:
- Homepage: http://localhost:5000
- Download Page: http://localhost:5000/download
- User Guide: http://localhost:5000/user_guide

## Client Application

### Installing the Client

1. With the server running, navigate to http://localhost:5000/download
2. Download the client installer
3. Run the installer and follow the on-screen instructions

### Building the Client from Source

```bash
# Navigate to the client directory
cd client

# Install client requirements
pip install pyaudio socketio tkinter pillow numpy

# Run the client
python client_app.py

# Build the executable (requires PyInstaller)
pip install pyinstaller
python setup.py
```

### Using the Client Application

1. Launch the Voice Transformer client
2. Enter the server URL (e.g., ws://localhost:5000)
3. Click "Connect"
4. Configure audio devices:
   - Select your physical microphone as input device
   - Select the virtual cable (VB-Cable) as output device
5. Configure voice transformation options:
   - Toggle noise cancellation, voice isolation, and echo cancellation
   - Select accent and gender transformation options
   - Upload or record voice samples for cloning
6. Click "Start Audio" to begin audio processing

## Voice Transformation Features

### Noise Cancellation
Removes background noise from your microphone input. Good for noisy environments.

### Voice Isolation
Focuses on your voice and removes other voices or sounds in the background.

### Echo Cancellation
Prevents audio feedback when using speakers instead of headphones.

### Accent Conversion
Available accents:
- American
- British
- Indian
- Neutral

### Gender Transformation
Available options:
- Male
- Female
- Neutral

### Voice Cloning
1. Upload a voice sample (5-10 seconds of clear speech)
2. Select the uploaded sample
3. Enable "Use Voice Clone"
4. Speak with the cloned voice in real-time

## Integrating with Other Applications

### Zoom Integration
1. Start the Voice Transformer client
2. Configure and start audio processing
3. Open Zoom and go to Settings → Audio
4. Select "VB-Cable Output" (or similar) as your microphone
5. Test your audio to ensure it works with the transformed voice

### Discord Integration
1. Start the Voice Transformer client
2. Configure and start audio processing
3. Open Discord and go to User Settings → Voice & Video
4. Select "VB-Cable Output" as your input device
5. Test your microphone

### WhatsApp, Teams, and Other Applications
1. Start the Voice Transformer client
2. Configure and start audio processing
3. Set "VB-Cable Output" as your default microphone in Windows sound settings
4. Make your calls as usual in any application

## Troubleshooting

### Server Won't Start
- Check if port 5000 is already in use: `netstat -ano | findstr :5000`
- Make sure all dependencies are installed: `pip install -r dependencies.txt`
- Check for errors in the console output

### Client Connection Issues
- Verify the server is running
- Check that you're using the correct server URL
- Ensure your firewall allows the connection

### No Audio Input/Output
- Verify microphone permissions
- Check if the correct input/output devices are selected
- Restart the application after changing audio devices

### Audio Latency Issues
- Reduce buffer size in the settings
- Close other audio-intensive applications
- Use a wired internet connection for better performance

### Virtual Audio Device Not Working
- Reinstall the virtual audio device
- Restart your computer after installation
- Make sure the device is not disabled in Windows sound settings

### Voice Transformation Not Working
- Check that the desired transformations are enabled
- Verify the server is processing audio (check audio meters)
- Ensure your microphone is working correctly