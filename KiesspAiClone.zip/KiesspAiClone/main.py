"""
Voice Transformation Server - Entry point for Gunicorn
"""
from server import app

# This is a simple entry point for Gunicorn
# Gunicorn will use this 'app' object as the WSGI application

if __name__ == "__main__":
    # This block won't be executed when run with Gunicorn
    from server import socketio
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)