"""
Voice Transformation Server - Main Flask Application
"""
import os
import logging
import uuid
import json
from flask import Flask, render_template, request, jsonify, send_from_directory, Response
from flask_socketio import SocketIO, emit

from audio_processing import AudioProcessor
from voice_transformation import VoiceTransformer

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", str(uuid.uuid4()))
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Initialize audio processor and voice transformer
audio_processor = AudioProcessor()
voice_transformer = VoiceTransformer()

# Active client sessions
active_sessions = {}

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/download')
def download_page():
    """Render the download page"""
    return render_template('download.html')

@app.route('/user_guide')
def user_guide():
    """Render the user guide page"""
    return render_template('user_guide.html')

@app.route('/api/available_transformations', methods=['GET'])
def available_transformations():
    """Return list of available voice transformations"""
    return jsonify({
        'accents': voice_transformer.get_available_accents(),
        'genders': voice_transformer.get_available_genders(),
        'personas': voice_transformer.get_available_personas()
    })

@app.route('/api/client_download', methods=['GET'])
def client_download():
    """Endpoint to download the Windows client application"""
    # In a real application, this would return the actual client installer
    # For this example, we return a placeholder
    return jsonify({
        'download_url': '/download/voicetransform_client_setup.exe',
        'version': '1.0.0'
    })

@app.route('/download/<path:filename>', methods=['GET'])
def download_file(filename):
    """Download handler for client files"""
    # Placeholder for actual file downloads
    return Response(
        "This would be the client executable in a real deployment",
        mimetype="application/octet-stream",
        headers={"Content-disposition": f"attachment; filename={filename}"})

@app.route('/api/upload_voice_sample', methods=['POST'])
def upload_voice_sample():
    """Handle uploaded voice samples for cloning"""
    if 'sample' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['sample']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Generate unique ID for this voice sample
    sample_id = str(uuid.uuid4())
    
    # Save file temporarily (in memory for this example)
    audio_data = file.read()
    
    # Process the voice sample with the voice transformer
    try:
        voice_transformer.process_voice_sample(sample_id, audio_data)
        return jsonify({
            'success': True,
            'sample_id': sample_id,
            'message': 'Voice sample processed successfully'
        })
    except Exception as e:
        logger.error(f"Error processing voice sample: {str(e)}")
        return jsonify({'error': str(e)}), 500

@socketio.on('connect')
def handle_connect():
    """Handle new WebSocket connection"""
    logger.info(f"Client connected: {request.sid}")
    active_sessions[request.sid] = {
        'noise_cancellation': True,
        'voice_isolation': True,
        'echo_cancellation': True,
        'accent': None,
        'gender': None,
        'voice_clone_id': None
    }
    emit('connection_established', {'session_id': request.sid})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle WebSocket disconnection"""
    logger.info(f"Client disconnected: {request.sid}")
    if request.sid in active_sessions:
        del active_sessions[request.sid]

@socketio.on('audio_stream')
def handle_audio_stream(data):
    """Process incoming audio stream from client"""
    if request.sid not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session = active_sessions[request.sid]
    
    try:
        # Convert binary audio data to format needed for processing
        audio_data = data.get('audio')
        if not audio_data:
            return
        
        # Process the audio based on active settings
        processed_audio = audio_processor.process_audio(
            audio_data,
            noise_cancellation=session['noise_cancellation'],
            voice_isolation=session['voice_isolation'],
            echo_cancellation=session['echo_cancellation']
        )
        
        # Apply voice transformations if enabled
        if session['accent'] or session['gender'] or session['voice_clone_id']:
            transformed_audio = voice_transformer.transform_voice(
                processed_audio,
                accent=session['accent'],
                gender=session['gender'],
                voice_clone_id=session['voice_clone_id']
            )
        else:
            transformed_audio = processed_audio
        
        # Send processed audio back to the client
        emit('processed_audio', {'audio': transformed_audio})
    
    except Exception as e:
        logger.error(f"Error processing audio stream: {str(e)}")
        emit('error', {'message': str(e)})

@socketio.on('update_settings')
def handle_update_settings(data):
    """Update session settings for voice transformation"""
    if request.sid not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session = active_sessions[request.sid]
    
    # Update settings based on client request
    if 'noise_cancellation' in data:
        session['noise_cancellation'] = data['noise_cancellation']
    
    if 'voice_isolation' in data:
        session['voice_isolation'] = data['voice_isolation']
    
    if 'echo_cancellation' in data:
        session['echo_cancellation'] = data['echo_cancellation']
    
    if 'accent' in data:
        session['accent'] = data['accent']
    
    if 'gender' in data:
        session['gender'] = data['gender']
    
    if 'voice_clone_id' in data:
        session['voice_clone_id'] = data['voice_clone_id']
    
    emit('settings_updated', session)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
