#!/usr/bin/env python3
"""
Voice Transformer Client - Setup script for PyInstaller

This script creates a Windows executable for the Voice Transformer client application.
"""
import sys
import os
from PyInstaller.__main__ import run

# Define file paths
script_dir = os.path.dirname(os.path.abspath(__file__))
client_path = os.path.join(script_dir, 'client_app.py')
icon_path = os.path.join(script_dir, 'resources', 'icon.ico')

# Check if paths exist
if not os.path.exists(client_path):
    print(f"Error: Could not find client script at {client_path}")
    sys.exit(1)

# Create icon file if it doesn't exist
if not os.path.exists(icon_path):
    os.makedirs(os.path.dirname(icon_path), exist_ok=True)
    
    # Create a minimal icon file (this would be a proper icon in a real application)
    # This is just a placeholder - in a real implementation, we would use a proper icon file
    try:
        from PIL import Image
        img = Image.new('RGB', (256, 256), color=(94, 114, 228))
        img.save(icon_path.replace('.ico', '.png'))
        img.save(icon_path)
        print(f"Created placeholder icon at {icon_path}")
    except:
        print("Warning: Could not create placeholder icon")
        icon_path = None

# Define PyInstaller arguments
pyinstaller_args = [
    '--name=VoiceTransformer',
    '--onefile',
    '--windowed',
    '--clean',
    '--add-data=README.md;.',
]

# Add icon if available
if icon_path and os.path.exists(icon_path):
    pyinstaller_args.append(f'--icon={icon_path}')

# Add hidden imports
pyinstaller_args.extend([
    '--hidden-import=PIL._tkinter_finder',
    '--hidden-import=engineio.async_drivers.threading',
])

# Add the main script
pyinstaller_args.append(client_path)

print("Building Voice Transformer client executable...")
print(f"PyInstaller arguments: {pyinstaller_args}")

# Run PyInstaller
run(pyinstaller_args)

print("\nBuild completed!")
print("The executable is located in the 'dist' folder.")

# Create Windows installer (in a real implementation, we would use a tool like NSIS)
print("\nTo create a Windows installer, consider using a tool like NSIS or Inno Setup.")
print("Example NSIS script:")
print("""
!define APP_NAME "Voice Transformer"
!define MAIN_APP_EXE "VoiceTransformer.exe"
!define INSTALL_TYPE "SetShellVarContext current"
!define REG_ROOT "HKCU"
!define REG_APP_PATH "Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\App Paths\\\\${MAIN_APP_EXE}"
!define UNINSTALL_PATH "Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Uninstall\\\\${APP_NAME}"

RequestExecutionLevel admin

Name "${APP_NAME}"
Icon "resources\\\\icon.ico"
OutFile "VoiceTransformer_Setup.exe"
InstallDir "$PROGRAMFILES\\\\${APP_NAME}"
InstallDirRegKey "${REG_ROOT}" "${REG_APP_PATH}" ""

!include "MUI2.nsh"

!define MUI_ABORTWARNING
!define MUI_ICON "resources\\\\icon.ico"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

Section "Install"
  SetOutPath "$INSTDIR"
  File "dist\\\\${MAIN_APP_EXE}"
  
  CreateDirectory "$SMPROGRAMS\\\\${APP_NAME}"
  CreateShortCut "$SMPROGRAMS\\\\${APP_NAME}\\\\${APP_NAME}.lnk" "$INSTDIR\\\\${MAIN_APP_EXE}"
  CreateShortCut "$DESKTOP\\\\${APP_NAME}.lnk" "$INSTDIR\\\\${MAIN_APP_EXE}"
  
  WriteUninstaller "$INSTDIR\\\\uninstall.exe"
  
  # Registry information for Add/Remove Programs
  WriteRegStr ${REG_ROOT} "${REG_APP_PATH}" "" "$INSTDIR\\\\${MAIN_APP_EXE}"
  WriteRegStr ${REG_ROOT} "${UNINSTALL_PATH}" "DisplayName" "${APP_NAME}"
  WriteRegStr ${REG_ROOT} "${UNINSTALL_PATH}" "UninstallString" "$INSTDIR\\\\uninstall.exe"
  WriteRegStr ${REG_ROOT} "${UNINSTALL_PATH}" "DisplayIcon" "$INSTDIR\\\\${MAIN_APP_EXE}"
  WriteRegStr ${REG_ROOT} "${UNINSTALL_PATH}" "Publisher" "Voice Transformer"
  WriteRegStr ${REG_ROOT} "${UNINSTALL_PATH}" "DisplayVersion" "1.0.0"
SectionEnd

Section "Uninstall"
  Delete "$INSTDIR\\\\${MAIN_APP_EXE}"
  Delete "$INSTDIR\\\\uninstall.exe"
  
  Delete "$SMPROGRAMS\\\\${APP_NAME}\\\\${APP_NAME}.lnk"
  Delete "$DESKTOP\\\\${APP_NAME}.lnk"
  
  RMDir "$SMPROGRAMS\\\\${APP_NAME}"
  RMDir "$INSTDIR"
  
  DeleteRegKey ${REG_ROOT} "${REG_APP_PATH}"
  DeleteRegKey ${REG_ROOT} "${UNINSTALL_PATH}"
SectionEnd
""")
