"""
User interface for the Voice Transformer client application
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import threading
import time
import logging
import webbrowser
from PIL import Image, ImageTk
import io
import base64

logger = logging.getLogger(__name__)

class VoiceTransformerUI:
    """Main UI class for the Voice Transformer client application"""
    
    def __init__(self, root, client):
        """
        Initialize the UI
        
        Args:
            root: Tkinter root window
            client: Parent VoiceTransformerClient instance
        """
        logger.info("Initializing Voice Transformer UI")
        
        self.root = root
        self.client = client
        
        # Configure the window
        self.root.title("Voice Transformer")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        
        # Set app icon
        # In a real application, we would use a proper icon file
        
        # Apply dark theme
        self.setup_theme()
        
        # Setup UI components
        self.setup_ui()
        
        # Audio level update variables
        self.input_level = 0
        self.output_level = 0
        self.level_update_running = True
        
        # Start level update thread
        self.level_update_thread = threading.Thread(target=self.level_update_loop)
        self.level_update_thread.daemon = True
        self.level_update_thread.start()
        
        # Register window close event
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        logger.info("Voice Transformer UI initialized")
    
    def setup_theme(self):
        """Setup and apply dark theme"""
        # Colors
        self.colors = {
            "bg": "#212529",
            "fg": "#e9ecef",
            "primary": "#5e72e4",
            "secondary": "#8392ab",
            "success": "#2dce89",
            "info": "#11cdef",
            "warning": "#fb6340",
            "danger": "#f5365c",
            "light": "#e9ecef",
            "dark": "#212529",
            "border": "#495057",
            "bg_accent": "#2c3136"
        }
        
        # Configure ttk styles
        self.style = ttk.Style()
        
        # Create custom theme
        self.style.theme_create("VoiceTransformerTheme", parent="alt", settings={
            "TNotebook": {"configure": {"background": self.colors["bg"], "tabmargins": [2, 5, 2, 0]}},
            "TNotebook.Tab": {
                "configure": {"padding": [10, 5], "background": self.colors["bg_accent"], "foreground": self.colors["fg"]},
                "map": {"background": [("selected", self.colors["primary"])], 
                        "foreground": [("selected", self.colors["light"])],
                        "expand": [("selected", [1, 1, 1, 0])]}
            },
            "TFrame": {"configure": {"background": self.colors["bg"]}},
            "TLabel": {"configure": {"background": self.colors["bg"], "foreground": self.colors["fg"]}},
            "TButton": {
                "configure": {"padding": [10, 5], "background": self.colors["primary"], "foreground": self.colors["light"]},
                "map": {"background": [("active", self.colors["info"])], "foreground": [("active", self.colors["light"])]}
            },
            "TCheckbutton": {"configure": {"background": self.colors["bg"], "foreground": self.colors["fg"]}},
            "TRadiobutton": {"configure": {"background": self.colors["bg"], "foreground": self.colors["fg"]}},
            "TProgressbar": {"configure": {"background": self.colors["primary"]}},
            "TScale": {"configure": {"background": self.colors["bg"]}},
            "TLabelframe": {"configure": {"background": self.colors["bg"], "foreground": self.colors["fg"]}},
            "TLabelframe.Label": {"configure": {"background": self.colors["bg"], "foreground": self.colors["fg"]}},
            "TCombobox": {"configure": {"fieldbackground": self.colors["bg_accent"], 
                                       "background": self.colors["primary"],
                                       "foreground": self.colors["fg"]}}
        })
        
        # Set the theme
        self.style.theme_use("VoiceTransformerTheme")
        
        # Configure root window colors
        self.root.configure(bg=self.colors["bg"])
    
    def setup_ui(self):
        """Setup UI components"""
        # Main frame
        self.main_frame = ttk.Frame(self.root, padding=10)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header with logo and status
        self.setup_header()
        
        # Tab control for different sections
        self.tab_control = ttk.Notebook(self.main_frame)
        self.tab_control.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Main controls tab
        self.main_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(self.main_tab, text="Voice Controls")
        self.setup_main_tab()
        
        # Settings tab
        self.settings_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(self.settings_tab, text="Settings")
        self.setup_settings_tab()
        
        # Help tab
        self.help_tab = ttk.Frame(self.tab_control, padding=10)
        self.tab_control.add(self.help_tab, text="Help")
        self.setup_help_tab()
        
        # Status bar
        self.status_frame = ttk.Frame(self.main_frame)
        self.status_frame.pack(fill=tk.X, pady=(10, 0))
        
        # Status message
        self.status_var = tk.StringVar(value="Ready")
        self.status_label = ttk.Label(self.status_frame, textvariable=self.status_var, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT)
        
        # Version info
        self.version_label = ttk.Label(self.status_frame, text="Version 1.0.0", anchor=tk.E)
        self.version_label.pack(side=tk.RIGHT)
    
    def setup_header(self):
        """Setup header with logo and status"""
        self.header_frame = ttk.Frame(self.main_frame)
        self.header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Title
        title_frame = ttk.Frame(self.header_frame)
        title_frame.pack(side=tk.LEFT)
        
        title_label = ttk.Label(title_frame, text="Voice Transformer", font=("Helvetica", 18, "bold"))
        title_label.pack(anchor=tk.W)
        
        subtitle_label = ttk.Label(title_frame, text="Real-time voice processing")
        subtitle_label.pack(anchor=tk.W)
        
        # Status and controls
        status_frame = ttk.Frame(self.header_frame)
        status_frame.pack(side=tk.RIGHT)
        
        # Connection status
        self.conn_status_frame = ttk.Frame(status_frame)
        self.conn_status_frame.pack(side=tk.TOP, anchor=tk.E, pady=5)
        
        self.conn_status_label = ttk.Label(self.conn_status_frame, text="Server:")
        self.conn_status_label.pack(side=tk.LEFT, padx=(0, 5))
        
        self.conn_status_indicator = tk.Canvas(self.conn_status_frame, width=15, height=15, 
                                               bg=self.colors["bg"], highlightthickness=0)
        self.conn_status_indicator.pack(side=tk.LEFT)
        self.conn_status_indicator.create_oval(2, 2, 13, 13, fill=self.colors["danger"], outline="")
        
        # Start/Stop button
        self.audio_button_var = tk.StringVar(value="Start Audio")
        self.audio_button = ttk.Button(status_frame, textvariable=self.audio_button_var, 
                                        command=self.toggle_audio_processing)
        self.audio_button.pack(side=tk.BOTTOM, anchor=tk.E)
    
    def setup_main_tab(self):
        """Setup the main voice controls tab"""
        # Split into two columns
        control_frame = ttk.Frame(self.main_tab)
        control_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        transform_frame = ttk.Frame(self.main_tab)
        transform_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        # Audio meters
        meters_frame = ttk.LabelFrame(control_frame, text="Audio Levels", padding=10)
        meters_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Input meter
        ttk.Label(meters_frame, text="Input:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.input_meter_frame = ttk.Frame(meters_frame)
        self.input_meter_frame.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=5)
        self.input_meter = ttk.Progressbar(self.input_meter_frame, length=200, mode="determinate", maximum=100)
        self.input_meter.pack(fill=tk.X)
        
        # Output meter
        ttk.Label(meters_frame, text="Output:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.output_meter_frame = ttk.Frame(meters_frame)
        self.output_meter_frame.grid(row=1, column=1, sticky=tk.EW, padx=5, pady=5)
        self.output_meter = ttk.Progressbar(self.output_meter_frame, length=200, mode="determinate", maximum=100)
        self.output_meter.pack(fill=tk.X)
        
        # Stretch the meter column
        meters_frame.columnconfigure(1, weight=1)
        
        # Basic controls
        basic_frame = ttk.LabelFrame(control_frame, text="Basic Controls", padding=10)
        basic_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Noise cancellation
        self.noise_cancel_var = tk.BooleanVar(value=True)
        self.noise_cancel_check = ttk.Checkbutton(
            basic_frame, 
            text="Noise Cancellation", 
            variable=self.noise_cancel_var,
            command=lambda: self.client.update_settings(noise_cancellation=self.noise_cancel_var.get())
        )
        self.noise_cancel_check.pack(anchor=tk.W, pady=2)
        
        # Voice isolation
        self.voice_isolation_var = tk.BooleanVar(value=True)
        self.voice_isolation_check = ttk.Checkbutton(
            basic_frame, 
            text="Voice Isolation", 
            variable=self.voice_isolation_var,
            command=lambda: self.client.update_settings(voice_isolation=self.voice_isolation_var.get())
        )
        self.voice_isolation_check.pack(anchor=tk.W, pady=2)
        
        # Echo cancellation
        self.echo_cancel_var = tk.BooleanVar(value=True)
        self.echo_cancel_check = ttk.Checkbutton(
            basic_frame, 
            text="Echo Cancellation", 
            variable=self.echo_cancel_var,
            command=lambda: self.client.update_settings(echo_cancellation=self.echo_cancel_var.get())
        )
        self.echo_cancel_check.pack(anchor=tk.W, pady=2)
        
        # Device selection
        devices_frame = ttk.LabelFrame(control_frame, text="Audio Devices", padding=10)
        devices_frame.pack(fill=tk.X)
        
        # Input device
        ttk.Label(devices_frame, text="Input Device:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        
        self.input_device_var = tk.StringVar()
        self.input_device_combo = ttk.Combobox(devices_frame, textvariable=self.input_device_var, width=30)
        self.input_device_combo.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=5)
        self.input_device_combo.bind("<<ComboboxSelected>>", self.on_input_device_change)
        
        # Output device
        ttk.Label(devices_frame, text="Output Device:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        
        self.output_device_var = tk.StringVar()
        self.output_device_combo = ttk.Combobox(devices_frame, textvariable=self.output_device_var, width=30)
        self.output_device_combo.grid(row=1, column=1, sticky=tk.EW, padx=5, pady=5)
        self.output_device_combo.bind("<<ComboboxSelected>>", self.on_output_device_change)
        
        # Refresh button
        refresh_button = ttk.Button(devices_frame, text="Refresh", command=self.refresh_devices, width=10)
        refresh_button.grid(row=1, column=2, padx=5, pady=5)
        
        # Stretch the device column
        devices_frame.columnconfigure(1, weight=1)
        
        # Voice transformation controls
        transform_controls = ttk.LabelFrame(transform_frame, text="Voice Transformation", padding=10)
        transform_controls.pack(fill=tk.X, pady=(0, 10))
        
        # Accent conversion
        ttk.Label(transform_controls, text="Accent:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        
        self.accent_var = tk.StringVar(value="None")
        self.accent_combo = ttk.Combobox(transform_controls, textvariable=self.accent_var, width=20)
        self.accent_combo.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=5)
        self.accent_combo['values'] = ["None"] + self.client.available_accents
        self.accent_combo.bind("<<ComboboxSelected>>", self.on_accent_change)
        
        # Gender transformation
        ttk.Label(transform_controls, text="Gender:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        
        self.gender_var = tk.StringVar(value="None")
        self.gender_combo = ttk.Combobox(transform_controls, textvariable=self.gender_var, width=20)
        self.gender_combo.grid(row=1, column=1, sticky=tk.EW, padx=5, pady=5)
        self.gender_combo['values'] = ["None"] + self.client.available_genders
        self.gender_combo.bind("<<ComboboxSelected>>", self.on_gender_change)
        
        # Stretch the combobox column
        transform_controls.columnconfigure(1, weight=1)
        
        # Voice cloning section
        voice_clone_frame = ttk.LabelFrame(transform_frame, text="Voice Cloning", padding=10)
        voice_clone_frame.pack(fill=tk.BOTH, expand=True)
        
        # Voice sample list
        list_frame = ttk.Frame(voice_clone_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        ttk.Label(list_frame, text="Voice Samples:").pack(anchor=tk.W, pady=(0, 5))
        
        # Sample list with scrollbar
        list_container = ttk.Frame(list_frame)
        list_container.pack(fill=tk.BOTH, expand=True)
        
        self.sample_list = tk.Listbox(list_container, bg=self.colors["bg_accent"], 
                                     fg=self.colors["fg"], selectbackground=self.colors["primary"])
        self.sample_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.sample_list.bind("<<ListboxSelect>>", self.on_sample_select)
        
        sample_scrollbar = ttk.Scrollbar(list_container, orient=tk.VERTICAL, command=self.sample_list.yview)
        sample_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.sample_list.config(yscrollcommand=sample_scrollbar.set)
        
        # Voice cloning buttons
        button_frame = ttk.Frame(voice_clone_frame)
        button_frame.pack(fill=tk.X)
        
        upload_button = ttk.Button(button_frame, text="Upload Sample", command=self.upload_voice_sample)
        upload_button.pack(side=tk.LEFT, padx=(0, 5))
        
        record_button = ttk.Button(button_frame, text="Record Sample", command=self.record_voice_sample)
        record_button.pack(side=tk.LEFT, padx=(0, 5))
        
        # Enable voice clone checkbox
        self.voice_clone_var = tk.BooleanVar(value=False)
        self.voice_clone_check = ttk.Checkbutton(
            voice_clone_frame, 
            text="Use Voice Clone", 
            variable=self.voice_clone_var,
            command=self.toggle_voice_clone
        )
        self.voice_clone_check.pack(anchor=tk.W, pady=(10, 0))
    
    def setup_settings_tab(self):
        """Setup the settings tab"""
        # Server settings
        server_frame = ttk.LabelFrame(self.settings_tab, text="Server Connection", padding=10)
        server_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Server URL
        ttk.Label(server_frame, text="Server URL:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        
        self.server_url_var = tk.StringVar(value=self.client.server_url)
        server_url_entry = ttk.Entry(server_frame, textvariable=self.server_url_var, width=40)
        server_url_entry.grid(row=0, column=1, sticky=tk.EW, padx=5, pady=5)
        
        # Connect button
        connect_button = ttk.Button(server_frame, text="Connect", command=self.connect_to_server)
        connect_button.grid(row=0, column=2, padx=5, pady=5)
        
        server_frame.columnconfigure(1, weight=1)
        
        # Audio settings
        audio_frame = ttk.LabelFrame(self.settings_tab, text="Audio Settings", padding=10)
        audio_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Buffer size
        ttk.Label(audio_frame, text="Buffer Size:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        
        self.buffer_size_var = tk.StringVar(value=self.client.audio_manager.buffer_size)
        buffer_values = ["2", "4", "8", "16", "32"]
        buffer_combo = ttk.Combobox(audio_frame, textvariable=self.buffer_size_var, values=buffer_values, width=10)
        buffer_combo.grid(row=0, column=1, sticky=tk.W, padx=5, pady=5)
        buffer_combo.bind("<<ComboboxSelected>>", self.on_buffer_size_change)
        
        ttk.Label(audio_frame, text="(Lower values = less latency, but may cause glitches)").grid(
            row=0, column=2, sticky=tk.W, padx=5, pady=5)
        
        # Virtual audio device check
        virtual_frame = ttk.LabelFrame(self.settings_tab, text="Virtual Audio Device", padding=10)
        virtual_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Check if virtual audio device is installed
        has_virtual_device = self.client.audio_manager.check_virtual_audio_device()
        
        if has_virtual_device:
            status_text = "Virtual audio device is installed and ready to use."
            status_label = ttk.Label(virtual_frame, text=status_text, foreground=self.colors["success"])
            status_label.pack(anchor=tk.W, pady=5)
            
            usage_text = ("To use with other applications:\n"
                         "1. Select the virtual cable as your output device in Voice Transformer\n"
                         "2. Select the virtual cable as your microphone in your calling application")
            usage_label = ttk.Label(virtual_frame, text=usage_text)
            usage_label.pack(anchor=tk.W, pady=5)
        else:
            status_text = "No virtual audio device detected. Required for integration with calling apps."
            status_label = ttk.Label(virtual_frame, text=status_text, foreground=self.colors["warning"])
            status_label.pack(anchor=tk.W, pady=5)
            
            install_button = ttk.Button(virtual_frame, text="Install Virtual Audio Device", 
                                       command=self.install_virtual_audio)
            install_button.pack(anchor=tk.W, pady=5)
        
        # Application settings
        app_frame = ttk.LabelFrame(self.settings_tab, text="Application Settings", padding=10)
        app_frame.pack(fill=tk.X)
        
        # Start with Windows
        self.autostart_var = tk.BooleanVar(value=False)
        autostart_check = ttk.Checkbutton(app_frame, text="Start with Windows", variable=self.autostart_var,
                                         command=self.toggle_autostart)
        autostart_check.pack(anchor=tk.W, pady=2)
        
        # Show tutorial on next start
        self.show_tutorial_var = tk.BooleanVar(value=self.client.show_tutorial)
        tutorial_check = ttk.Checkbutton(app_frame, text="Show tutorial on next start", 
                                        variable=self.show_tutorial_var,
                                        command=self.toggle_tutorial)
        tutorial_check.pack(anchor=tk.W, pady=2)
        
        # Reset button
        reset_button = ttk.Button(app_frame, text="Reset All Settings", command=self.confirm_reset_settings)
        reset_button.pack(anchor=tk.W, pady=(10, 0))
    
    def setup_help_tab(self):
        """Setup the help tab"""
        # Add a notebook for help topics
        help_notebook = ttk.Notebook(self.help_tab)
        help_notebook.pack(fill=tk.BOTH, expand=True)
        
        # Quick Start tab
        quickstart_tab = ttk.Frame(help_notebook, padding=10)
        help_notebook.add(quickstart_tab, text="Quick Start")
        
        # Quick start content
        quickstart_text = (
            "Voice Transformer Quick Start Guide\n\n"
            "1. Server Connection:\n"
            "   - Ensure the Voice Transformer server is running in VS Code terminal\n"
            "   - Connect to the server using the default URL (ws://localhost:5000)\n\n"
            "2. Audio Setup:\n"
            "   - Select your physical microphone as the input device\n"
            "   - Select a virtual audio cable as the output device\n"
            "   - Click 'Start Audio' to begin processing\n\n"
            "3. Voice Transformations:\n"
            "   - Enable/disable noise cancellation, voice isolation, and echo cancellation\n"
            "   - Select an accent to convert your voice\n"
            "   - Choose a gender transformation option\n"
            "   - Upload a voice sample for cloning\n\n"
            "4. Using with Calling Apps:\n"
            "   - In your calling application (Zoom, Discord, etc.), select the virtual audio cable as your microphone\n"
            "   - Your transformed voice will be heard by others in the call\n\n"
            "For more detailed instructions, visit the User Guide."
        )
        
        # Use a Text widget for better formatting
        quickstart_content = tk.Text(quickstart_tab, wrap=tk.WORD, bg=self.colors["bg"], 
                                    fg=self.colors["fg"], relief=tk.FLAT)
        quickstart_content.pack(fill=tk.BOTH, expand=True)
        quickstart_content.insert(tk.END, quickstart_text)
        quickstart_content.config(state=tk.DISABLED)
        
        # Troubleshooting tab
        troubleshoot_tab = ttk.Frame(help_notebook, padding=10)
        help_notebook.add(troubleshoot_tab, text="Troubleshooting")
        
        # Troubleshooting content
        troubleshoot_text = (
            "Troubleshooting Guide\n\n"
            "Problem: Cannot connect to server\n"
            "Solutions:\n"
            "- Ensure the server is running in VS Code terminal (python run.py)\n"
            "- Check server URL (default is ws://localhost:5000)\n"
            "- Check if a firewall is blocking the connection\n\n"
            "Problem: No audio input/output\n"
            "Solutions:\n"
            "- Ensure microphone permissions are granted\n"
            "- Check that the correct input and output devices are selected\n"
            "- Verify that the virtual audio device is properly installed\n"
            "- Try restarting the application\n\n"
            "Problem: High latency or poor performance\n"
            "Solutions:\n"
            "- Check CPU usage - voice transformation is computationally intensive\n"
            "- Try disabling features you don't need\n"
            "- Ensure the server and client are on the same network\n"
            "- Close other resource-intensive applications\n"
            "- Try increasing the buffer size in Settings\n\n"
            "Problem: Voice transformations not working\n"
            "Solutions:\n"
            "- Ensure transformations are enabled\n"
            "- Check that audio is flowing through the system\n"
            "- Try with different transformation settings\n"
            "- Restart the client and reconnect to the server\n\n"
            "For more help, visit the User Guide."
        )
        
        # Use a Text widget for better formatting
        troubleshoot_content = tk.Text(troubleshoot_tab, wrap=tk.WORD, bg=self.colors["bg"], 
                                      fg=self.colors["fg"], relief=tk.FLAT)
        troubleshoot_content.pack(fill=tk.BOTH, expand=True)
        troubleshoot_content.insert(tk.END, troubleshoot_text)
        troubleshoot_content.config(state=tk.DISABLED)
        
        # About tab
        about_tab = ttk.Frame(help_notebook, padding=10)
        help_notebook.add(about_tab, text="About")
        
        # About content
        about_title = ttk.Label(about_tab, text="Voice Transformer", font=("Helvetica", 16, "bold"))
        about_title.pack(pady=(0, 5))
        
        about_version = ttk.Label(about_tab, text="Version 1.0.0")
        about_version.pack(pady=(0, 20))
        
        about_desc = ttk.Label(about_tab, text=(
            "Voice Transformer is a free, open-source voice transformation system\n"
            "for real-time voice processing during calls and meetings."
        ))
        about_desc.pack(pady=(0, 20))
        
        about_features = ttk.Label(about_tab, text=(
            "Features:\n"
            "- Noise Cancellation\n"
            "- Voice Isolation\n"
            "- Echo Cancellation\n"
            "- Accent Conversion\n"
            "- Gender Transformation\n"
            "- Voice Cloning"
        ), justify=tk.LEFT)
        about_features.pack(pady=(0, 20))
        
        # Links
        links_frame = ttk.Frame(about_tab)
        links_frame.pack(pady=(0, 20))
        
        guide_button = ttk.Button(links_frame, text="User Guide", command=self.client.open_user_guide)
        guide_button.pack(side=tk.LEFT, padx=5)
        
        website_button = ttk.Button(links_frame, text="Website", 
                                   command=lambda: webbrowser.open("http://localhost:5000"))
        website_button.pack(side=tk.LEFT, padx=5)
        
        # Copyright
        copyright_label = ttk.Label(about_tab, text="© 2023 Voice Transformer. All rights reserved.")
        copyright_label.pack(side=tk.BOTTOM, pady=10)
    
    def populate_device_lists(self):
        """Populate the audio device lists"""
        # Get available devices
        devices = self.client.audio_manager.available_devices
        
        # Input devices - only those with input channels
        input_devices = [dev for dev in devices if dev['input_channels'] > 0]
        self.input_device_combo['values'] = [f"{dev['name']}" for dev in input_devices]
        
        # Set current input device
        if self.client.audio_manager.input_device_index is not None:
            for i, dev in enumerate(input_devices):
                if dev['index'] == self.client.audio_manager.input_device_index:
                    self.input_device_combo.current(i)
                    break
        
        # Output devices - only those with output channels
        output_devices = [dev for dev in devices if dev['output_channels'] > 0]
        self.output_device_combo['values'] = [f"{dev['name']}" for dev in output_devices]
        
        # Set current output device
        if self.client.audio_manager.output_device_index is not None:
            for i, dev in enumerate(output_devices):
                if dev['index'] == self.client.audio_manager.output_device_index:
                    self.output_device_combo.current(i)
                    break
    
    def update_audio_levels(self, input_level, output_level):
        """
        Update audio level meters
        
        Args:
            input_level: Input audio level (0.0 to 1.0)
            output_level: Output audio level (0.0 to 1.0)
        """
        self.input_level = input_level
        self.output_level = output_level
    
    def level_update_loop(self):
        """Thread function to update audio level meters"""
        while self.level_update_running:
            # Update meters on the main thread
            self.root.after(0, self._update_meters)
            time.sleep(0.05)
    
    def _update_meters(self):
        """Update the audio level meters (called on main thread)"""
        self.input_meter['value'] = self.input_level * 100
        self.output_meter['value'] = self.output_level * 100
    
    def update_connection_status(self, connected):
        """
        Update the connection status indicator
        
        Args:
            connected: True if connected, False otherwise
        """
        if connected:
            self.conn_status_indicator.itemconfig(1, fill=self.colors["success"])
            self.status_var.set("Connected to server")
            # Enable audio button if not already enabled
            self.audio_button.config(state=tk.NORMAL)
        else:
            self.conn_status_indicator.itemconfig(1, fill=self.colors["danger"])
            self.status_var.set("Not connected to server")
            # Reset audio button
            self.audio_button_var.set("Start Audio")
            # Disable audio button
            self.audio_button.config(state=tk.DISABLED)
            # Stop audio if running
            self.client.stop_audio_stream()
    
    def update_transformation_options(self):
        """Update the transformation option dropdowns"""
        # Update accent options
        self.accent_combo['values'] = ["None"] + self.client.available_accents
        
        # Update gender options
        self.gender_combo['values'] = ["None"] + self.client.available_genders
    
    def update_voice_samples(self):
        """Update the voice sample listbox"""
        # Clear the list
        self.sample_list.delete(0, tk.END)
        
        # Add each sample
        for sample_id, sample in self.client.voice_samples.items():
            self.sample_list.insert(tk.END, sample['name'])
    
    def update_settings_display(self):
        """Update UI elements to match current settings"""
        # Update checkboxes
        self.noise_cancel_var.set(self.client.settings['noise_cancellation'])
        self.voice_isolation_var.set(self.client.settings['voice_isolation'])
        self.echo_cancel_var.set(self.client.settings['echo_cancellation'])
        
        # Update dropdowns
        if self.client.settings['accent'] is None:
            self.accent_var.set("None")
        else:
            self.accent_var.set(self.client.settings['accent'])
        
        if self.client.settings['gender'] is None:
            self.gender_var.set("None")
        else:
            self.gender_var.set(self.client.settings['gender'])
        
        # Update voice clone
        if self.client.settings['voice_clone_id'] is None:
            self.voice_clone_var.set(False)
        else:
            self.voice_clone_var.set(True)
            
            # Try to select the correct sample in the list
            for i, sample_id in enumerate(self.client.voice_samples.keys()):
                if sample_id == self.client.settings['voice_clone_id']:
                    self.sample_list.selection_clear(0, tk.END)
                    self.sample_list.selection_set(i)
                    self.sample_list.see(i)
                    break
    
    def toggle_audio_processing(self):
        """Toggle audio processing on/off"""
        if self.audio_button_var.get() == "Start Audio":
            # Check if connected to server
            if not self.client.connected:
                self.show_error("Not Connected", "Please connect to the server first.")
                return
            
            # Check if input/output devices are selected
            if (self.client.audio_manager.input_device_index is None or
                self.client.audio_manager.output_device_index is None):
                self.show_error("Device Error", "Please select input and output devices.")
                return
            
            # Start audio processing
            if self.client.start_audio_stream():
                self.audio_button_var.set("Stop Audio")
                self.status_var.set("Audio processing active")
            else:
                self.show_error("Audio Error", "Failed to start audio processing.")
        else:
            # Stop audio processing
            self.client.stop_audio_stream()
            self.audio_button_var.set("Start Audio")
            self.status_var.set("Audio processing stopped")
    
    def connect_to_server(self):
        """Connect to the server with the specified URL"""
        server_url = self.server_url_var.get()
        
        if not server_url:
            self.show_error("Connection Error", "Please enter a server URL.")
            return
        
        # Update status
        self.status_var.set("Connecting to server...")
        
        # Try to connect (non-blocking)
        threading.Thread(target=self._connect_thread, args=(server_url,), daemon=True).start()
    
    def _connect_thread(self, server_url):
        """Thread function to connect to the server"""
        self.client.connect_to_server(server_url)
    
    def refresh_devices(self):
        """Refresh the audio device lists"""
        # Update the available devices
        self.client.audio_manager.available_devices = self.client.audio_manager.get_available_devices()
        
        # Populate the lists
        self.populate_device_lists()
        
        # Update status
        self.status_var.set("Audio devices refreshed")
    
    def on_input_device_change(self, event):
        """Handle input device selection"""
        selected_index = self.input_device_combo.current()
        if selected_index >= 0:
            # Get the device info
            devices = [dev for dev in self.client.audio_manager.available_devices if dev['input_channels'] > 0]
            device_index = devices[selected_index]['index']
            
            # Set the device
            self.client.audio_manager.set_input_device(device_index)
            
            # Update status
            self.status_var.set(f"Input device set to: {devices[selected_index]['name']}")
    
    def on_output_device_change(self, event):
        """Handle output device selection"""
        selected_index = self.output_device_combo.current()
        if selected_index >= 0:
            # Get the device info
            devices = [dev for dev in self.client.audio_manager.available_devices if dev['output_channels'] > 0]
            device_index = devices[selected_index]['index']
            
            # Set the device
            self.client.audio_manager.set_output_device(device_index)
            
            # Update status
            self.status_var.set(f"Output device set to: {devices[selected_index]['name']}")
    
    def on_buffer_size_change(self, event):
        """Handle buffer size change"""
        try:
            # Get the new buffer size
            buffer_size = int(self.buffer_size_var.get())
            
            # Check if we need to restart audio
            restart = self.client.audio_manager.running
            
            # Stop if running
            if restart:
                self.client.stop_audio_stream()
            
            # Update buffer size
            self.client.audio_manager.buffer_size = buffer_size
            
            # Save in config
            self.client.config.set('Audio', 'buffer_size', str(buffer_size))
            self.client.save_config()
            
            # Restart if needed
            if restart:
                self.client.start_audio_stream()
            
            # Update status
            self.status_var.set(f"Buffer size set to: {buffer_size}")
            
        except ValueError:
            self.show_error("Invalid Value", "Please enter a valid number for buffer size.")
    
    def on_accent_change(self, event):
        """Handle accent selection"""
        accent = self.accent_var.get()
        
        # Convert "None" to None
        if accent == "None":
            accent = None
        
        # Update client settings
        self.client.update_settings(accent=accent)
        
        # Update status
        if accent:
            self.status_var.set(f"Accent set to: {accent}")
        else:
            self.status_var.set("Accent conversion disabled")
    
    def on_gender_change(self, event):
        """Handle gender selection"""
        gender = self.gender_var.get()
        
        # Convert "None" to None
        if gender == "None":
            gender = None
        
        # Update client settings
        self.client.update_settings(gender=gender)
        
        # Update status
        if gender:
            self.status_var.set(f"Gender set to: {gender}")
        else:
            self.status_var.set("Gender transformation disabled")
    
    def on_sample_select(self, event):
        """Handle voice sample selection"""
        # Only update if voice cloning is enabled
        if self.voice_clone_var.get():
            selection = self.sample_list.curselection()
            if selection:
                index = selection[0]
                sample_id = list(self.client.voice_samples.keys())[index]
                
                # Update client settings
                self.client.update_settings(voice_clone_id=sample_id)
                
                # Update status
                self.status_var.set(f"Voice clone set to: {self.client.voice_samples[sample_id]['name']}")
    
    def toggle_voice_clone(self):
        """Toggle voice cloning on/off"""
        if self.voice_clone_var.get():
            # Enable voice cloning
            selection = self.sample_list.curselection()
            if selection:
                index = selection[0]
                sample_id = list(self.client.voice_samples.keys())[index]
                
                # Update client settings
                self.client.update_settings(voice_clone_id=sample_id)
                
                # Update status
                self.status_var.set(f"Voice clone enabled: {self.client.voice_samples[sample_id]['name']}")
            else:
                # No selection, but checkbox is checked
                if self.client.voice_samples:
                    # Select the first sample
                    self.sample_list.selection_set(0)
                    sample_id = list(self.client.voice_samples.keys())[0]
                    
                    # Update client settings
                    self.client.update_settings(voice_clone_id=sample_id)
                    
                    # Update status
                    self.status_var.set(f"Voice clone enabled: {self.client.voice_samples[sample_id]['name']}")
                else:
                    # No samples available
                    self.voice_clone_var.set(False)
                    self.show_error("No Samples", "Please upload or record a voice sample first.")
        else:
            # Disable voice cloning
            self.client.update_settings(voice_clone_id=None)
            self.status_var.set("Voice cloning disabled")
    
    def upload_voice_sample(self):
        """Upload a voice sample file"""
        file_path = filedialog.askopenfilename(
            title="Select Voice Sample",
            filetypes=[("Audio Files", "*.wav *.mp3 *.ogg")]
        )
        
        if file_path:
            # Show progress
            self.status_var.set("Uploading voice sample...")
            
            # Upload in a separate thread
            threading.Thread(target=self._upload_sample_thread, args=(file_path,), daemon=True).start()
    
    def _upload_sample_thread(self, file_path):
        """Thread function to upload a voice sample"""
        sample_id = self.client.upload_voice_sample(file_path)
        
        if sample_id:
            # Update UI on main thread
            self.root.after(0, lambda: self.update_voice_samples())
            self.root.after(0, lambda: self.status_var.set("Voice sample uploaded successfully"))
        else:
            # Update UI on main thread
            self.root.after(0, lambda: self.status_var.set("Failed to upload voice sample"))
    
    def record_voice_sample(self):
        """Record a voice sample"""
        # Check if audio is running
        if not self.client.audio_manager.running:
            self.show_error("Audio Not Running", "Please start audio processing first.")
            return
        
        # Ask for confirmation
        result = messagebox.askyesno(
            "Record Voice Sample",
            "The system will record a 5-second sample of your voice.\n\n"
            "Please speak clearly during the recording.\n\n"
            "Ready to start recording?"
        )
        
        if result:
            # Show countdown dialog
            self.show_recording_countdown()
    
    def show_recording_countdown(self):
        """Show a countdown dialog before recording"""
        countdown_window = tk.Toplevel(self.root)
        countdown_window.title("Recording Countdown")
        countdown_window.geometry("300x150")
        countdown_window.configure(bg=self.colors["bg"])
        countdown_window.transient(self.root)
        countdown_window.grab_set()
        
        # Center the window
        countdown_window.update_idletasks()
        width = countdown_window.winfo_width()
        height = countdown_window.winfo_height()
        x = (countdown_window.winfo_screenwidth() // 2) - (width // 2)
        y = (countdown_window.winfo_screenheight() // 2) - (height // 2)
        countdown_window.geometry('{}x{}+{}+{}'.format(width, height, x, y))
        
        # Countdown label
        countdown_var = tk.StringVar(value="Recording will start in: 3")
        countdown_label = ttk.Label(countdown_window, textvariable=countdown_var, font=("Helvetica", 14))
        countdown_label.pack(expand=True, pady=10)
        
        # Instructions
        instruction_label = ttk.Label(countdown_window, text="Please speak clearly during the recording.", 
                                     wraplength=250)
        instruction_label.pack(expand=True)
        
        # Countdown function
        def countdown(count):
            if count > 0:
                countdown_var.set(f"Recording will start in: {count}")
                countdown_window.after(1000, countdown, count - 1)
            else:
                countdown_var.set("Recording...")
                countdown_window.after(100, start_recording, countdown_window)
        
        # Start recording function
        def start_recording(window):
            # Start recording in a separate thread
            threading.Thread(target=self._record_sample_thread, args=(window,), daemon=True).start()
        
        # Start countdown
        countdown(3)
    
    def _record_sample_thread(self, countdown_window):
        """Thread function to record a voice sample"""
        # Record a 5-second sample
        file_path = self.client.audio_manager.record_sample(duration=5)
        
        if file_path:
            # Upload the sample
            sample_id = self.client.upload_voice_sample(file_path)
            
            if sample_id:
                # Update UI on main thread
                self.root.after(0, lambda: self.update_voice_samples())
                self.root.after(0, lambda: self.status_var.set("Voice sample recorded and uploaded successfully"))
            else:
                # Update UI on main thread
                self.root.after(0, lambda: self.status_var.set("Failed to upload recorded voice sample"))
        else:
            # Update UI on main thread
            self.root.after(0, lambda: self.status_var.set("Failed to record voice sample"))
        
        # Close the countdown window
        self.root.after(0, countdown_window.destroy)
    
    def install_virtual_audio_device(self):
        """Show instructions for installing a virtual audio device"""
        message = self.client.audio_manager.install_virtual_audio_device()
        
        result = messagebox.askyesno("Virtual Audio Device", message)
        
        if result:
            # Open download page
            webbrowser.open("https://vb-audio.com/Cable/")
    
    def toggle_autostart(self):
        """Toggle automatic startup with Windows"""
        try:
            import winreg
            
            autostart = self.autostart_var.get()
            
            # Get path to executable
            exe_path = os.path.abspath(sys.executable)
            if os.path.basename(exe_path).lower() == "python.exe":
                # Running from Python, use script path
                exe_path = os.path.abspath(sys.argv[0])
            
            # Open registry key
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0, winreg.KEY_SET_VALUE
            )
            
            if autostart:
                # Add to startup
                winreg.SetValueEx(key, "VoiceTransformer", 0, winreg.REG_SZ, f'"{exe_path}"')
                self.status_var.set("Added to Windows startup")
            else:
                # Remove from startup
                try:
                    winreg.DeleteValue(key, "VoiceTransformer")
                    self.status_var.set("Removed from Windows startup")
                except FileNotFoundError:
                    pass
            
            winreg.CloseKey(key)
            
        except Exception as e:
            logger.error(f"Error toggling autostart: {str(e)}")
            self.show_error("Error", f"Failed to update startup settings: {str(e)}")
            
            # Reset checkbox
            self.autostart_var.set(not autostart)
    
    def toggle_tutorial(self):
        """Toggle showing tutorial on next start"""
        show_tutorial = self.show_tutorial_var.get()
        
        # Update client setting
        self.client.show_tutorial = show_tutorial
        self.client.config.set('General', 'first_run', str(show_tutorial).lower())
        self.client.save_config()
        
        if show_tutorial:
            self.status_var.set("Tutorial will be shown on next start")
        else:
            self.status_var.set("Tutorial will not be shown on next start")
    
    def confirm_reset_settings(self):
        """Confirm and reset all settings"""
        result = messagebox.askyesno(
            "Reset Settings",
            "Are you sure you want to reset all settings to default?\n\n"
            "This will reset server connection, audio devices, and all voice transformation settings."
        )
        
        if result:
            self.reset_settings()
    
    def reset_settings(self):
        """Reset all settings to default"""
        try:
            # Stop audio if running
            if self.client.audio_manager.running:
                self.client.stop_audio_stream()
            
            # Disconnect from server
            self.client.disconnect_from_server()
            
            # Delete config file
            if os.path.exists(self.client.config_path):
                os.remove(self.client.config_path)
            
            # Create default config
            self.client.create_default_config()
            
            # Reload settings
            self.client.load_config()
            self.client.audio_manager.load_device_settings()
            
            # Update UI
            self.server_url_var.set(self.client.server_url)
            self.buffer_size_var.set(self.client.audio_manager.buffer_size)
            self.show_tutorial_var.set(True)
            
            # Reset transformation settings
            self.client.settings = {
                'noise_cancellation': True,
                'voice_isolation': True,
                'echo_cancellation': True,
                'accent': None,
                'gender': None,
                'voice_clone_id': None
            }
            
            # Update UI with new settings
            self.update_settings_display()
            self.populate_device_lists()
            
            # Update status
            self.status_var.set("All settings reset to default")
            
        except Exception as e:
            logger.error(f"Error resetting settings: {str(e)}")
            self.show_error("Error", f"Failed to reset settings: {str(e)}")
    
    def show_tutorial(self):
        """Show the first-run tutorial"""
        # Create tutorial window
        tutorial_window = tk.Toplevel(self.root)
        tutorial_window.title("Voice Transformer Tutorial")
        tutorial_window.geometry("700x500")
        tutorial_window.configure(bg=self.colors["bg"])
        tutorial_window.transient(self.root)
        tutorial_window.grab_set()
        
        # Center the window
        tutorial_window.update_idletasks()
        width = tutorial_window.winfo_width()
        height = tutorial_window.winfo_height()
        x = (tutorial_window.winfo_screenwidth() // 2) - (width // 2)
        y = (tutorial_window.winfo_screenheight() // 2) - (height // 2)
        tutorial_window.geometry('{}x{}+{}+{}'.format(width, height, x, y))
        
        # Tutorial steps
        tutorial_steps = [
            {
                "title": "Welcome to Voice Transformer!",
                "content": (
                    "This tutorial will guide you through setting up and using the Voice Transformer application.\n\n"
                    "Voice Transformer allows you to change your voice in real-time during calls and meetings."
                ),
                "image": None
            },
            {
                "title": "Step 1: Connect to the Server",
                "content": (
                    "First, you need to connect to the Voice Transformer server.\n\n"
                    "Make sure the server is running in VS Code terminal (python run.py).\n\n"
                    "Go to the Settings tab and enter the server URL (default: ws://localhost:5000)."
                ),
                "image": None
            },
            {
                "title": "Step 2: Configure Audio Devices",
                "content": (
                    "Select your microphone as the Input Device.\n\n"
                    "For the Output Device, select a virtual audio cable (like VB-Cable).\n\n"
                    "If you don't have a virtual audio cable installed, you'll need to install one."
                ),
                "image": None
            },
            {
                "title": "Step 3: Start Audio Processing",
                "content": (
                    "Click the 'Start Audio' button to begin processing your voice.\n\n"
                    "You should see the audio level meters responding to your voice."
                ),
                "image": None
            },
            {
                "title": "Step 4: Apply Voice Transformations",
                "content": (
                    "Enable Noise Cancellation, Voice Isolation, and Echo Cancellation as needed.\n\n"
                    "Select an accent from the dropdown to change your accent.\n\n"
                    "Choose a gender transformation option to change your voice."
                ),
                "image": None
            },
            {
                "title": "Step 5: Upload or Record a Voice Sample",
                "content": (
                    "To clone a voice, upload an audio file of the target voice or record a sample.\n\n"
                    "Select the voice sample from the list and enable Voice Cloning."
                ),
                "image": None
            },
            {
                "title": "Step 6: Use with Calling Applications",
                "content": (
                    "In your calling application (Zoom, Discord, WhatsApp, etc.), select the virtual audio device as your microphone.\n\n"
                    "Your transformed voice will be heard by others in the call."
                ),
                "image": None
            },
            {
                "title": "Setup Complete!",
                "content": (
                    "You're now ready to use Voice Transformer!\n\n"
                    "For more information, check the Help tab or visit the User Guide."
                ),
                "image": None
            }
        ]
        
        # Current step
        current_step = 0
        
        # Tutorial content frame
        content_frame = ttk.Frame(tutorial_window, padding=20)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Step title
        title_var = tk.StringVar()
        title_label = ttk.Label(content_frame, textvariable=title_var, font=("Helvetica", 16, "bold"))
        title_label.pack(anchor=tk.W, pady=(0, 20))
        
        # Step content
        content_var = tk.StringVar()
        content_label = ttk.Label(content_frame, textvariable=content_var, wraplength=650, justify=tk.LEFT)
        content_label.pack(fill=tk.BOTH, expand=True)
        
        # Navigation buttons
        button_frame = ttk.Frame(tutorial_window, padding=10)
        button_frame.pack(fill=tk.X)
        
        # Skip button
        skip_button = ttk.Button(button_frame, text="Skip Tutorial", 
                                command=lambda: self.complete_tutorial(tutorial_window))
        skip_button.pack(side=tk.LEFT, padx=5)
        
        # Back button
        back_button = ttk.Button(button_frame, text="Back", 
                                command=lambda: navigate_step(-1))
        back_button.pack(side=tk.LEFT, padx=5)
        
        # Next/Finish button
        next_var = tk.StringVar(value="Next")
        next_button = ttk.Button(button_frame, textvariable=next_var, 
                                command=lambda: navigate_step(1))
        next_button.pack(side=tk.RIGHT, padx=5)
        
        # Progress indicator
        progress_var = tk.StringVar()
        progress_label = ttk.Label(button_frame, textvariable=progress_var)
        progress_label.pack(side=tk.RIGHT, padx=10)
        
        # Navigate between steps
        def navigate_step(direction):
            nonlocal current_step
            
            # Calculate new step
            new_step = current_step + direction
            
            # Check bounds
            if new_step < 0:
                new_step = 0
            elif new_step >= len(tutorial_steps):
                # Last step, finish tutorial
                self.complete_tutorial(tutorial_window)
                return
            
            # Update current step
            current_step = new_step
            
            # Update content
            title_var.set(tutorial_steps[current_step]["title"])
            content_var.set(tutorial_steps[current_step]["content"])
            
            # Update navigation buttons
            if current_step == 0:
                back_button.config(state=tk.DISABLED)
            else:
                back_button.config(state=tk.NORMAL)
            
            if current_step == len(tutorial_steps) - 1:
                next_var.set("Finish")
            else:
                next_var.set("Next")
            
            # Update progress
            progress_var.set(f"Step {current_step + 1} of {len(tutorial_steps)}")
        
        # Initialize with first step
        navigate_step(0)
    
    def complete_tutorial(self, tutorial_window):
        """Complete the tutorial"""
        # Close tutorial window
        tutorial_window.destroy()
        
        # Update config to not show tutorial next time
        self.client.show_tutorial = False
        self.client.config.set('General', 'first_run', 'false')
        self.client.save_config()
        
        # Update checkbox
        self.show_tutorial_var.set(False)
        
        # Give focus back to main window
        self.root.focus_force()
    
    def show_error(self, title, message):
        """Show an error dialog"""
        messagebox.showerror(title, message)
    
    def on_close(self):
        """Handle window close event"""
        # Stop level update thread
        self.level_update_running = False
        
        # Exit the application
        self.client.exit_application()
