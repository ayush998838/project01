# Voice Transformer Client

The Voice Transformer client application provides a user interface for controlling the Voice Transformer system. It connects to the Voice Transformer server to process audio and transform your voice in real-time.

## Features

- Noise cancellation
- Voice isolation
- Echo cancellation
- Accent conversion
- Gender transformation
- Voice cloning
- Integration with calling applications (Zoom, Discord, WhatsApp, etc.)

## Requirements

- Windows 10 or newer
- Python 3.8 or newer
- Voice Transformer server running
- Virtual audio device (e.g., VB-Cable)

## Installation

### Option 1: Run from source

1. Install the required dependencies:

```bash
pip install pyaudio socketio tkinter pillow numpy
