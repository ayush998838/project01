"""
Audio manager for the Voice Transformer client application

Handles microphone input, audio processing, and output to virtual devices
"""
import logging
import threading
import time
import queue
import numpy as np
import pyaudio
import base64
import wave
import os
import ctypes

logger = logging.getLogger(__name__)

class AudioManager:
    """Handles audio input/output and processing for the client application"""
    
    def __init__(self, client):
        """
        Initialize the audio manager
        
        Args:
            client: Parent VoiceTransformerClient instance
        """
        logger.info("Initializing AudioManager")
        
        self.client = client
        
        # PyAudio setup
        self.pyaudio = pyaudio.PyAudio()
        
        # Audio parameters
        self.sample_rate = 16000
        self.channels = 1
        self.format = pyaudio.paInt16
        self.chunk_size = 1024
        self.buffer_size = 10  # Number of chunks to buffer
        
        # Audio streams
        self.input_stream = None
        self.output_stream = None
        
        # Audio devices
        self.input_device_index = None
        self.output_device_index = None
        self.available_devices = self.get_available_devices()
        
        # Processing state
        self.running = False
        self.audio_thread = None
        
        # Audio buffers
        self.input_buffer = queue.Queue(maxsize=self.buffer_size)
        self.output_buffer = queue.Queue(maxsize=self.buffer_size)
        
        # Audio level monitors
        self.input_level = 0
        self.output_level = 0
        
        # Load default devices from config
        self.load_device_settings()
        
        logger.info("AudioManager initialized")
    
    def get_available_devices(self):
        """
        Get list of available audio devices
        
        Returns:
            List of dictionaries with device information
        """
        devices = []
        
        try:
            info = self.pyaudio.get_host_api_info_by_index(0)
            num_devices = info.get('deviceCount')
            
            for i in range(num_devices):
                device_info = self.pyaudio.get_device_info_by_host_api_device_index(0, i)
                devices.append({
                    'index': device_info.get('index'),
                    'name': device_info.get('name'),
                    'input_channels': device_info.get('maxInputChannels'),
                    'output_channels': device_info.get('maxOutputChannels'),
                    'default_sample_rate': device_info.get('defaultSampleRate')
                })
            
            logger.info(f"Found {len(devices)} audio devices")
            
        except Exception as e:
            logger.error(f"Error getting audio devices: {str(e)}")
        
        return devices
    
    def load_device_settings(self):
        """Load audio device settings from configuration"""
        try:
            config = self.client.config
            
            # Load input device
            if config.has_option('Audio', 'input_device'):
                self.input_device_index = config.getint('Audio', 'input_device')
            else:
                # Use default input device
                default_input = self.pyaudio.get_default_input_device_info()
                self.input_device_index = default_input['index']
                config.set('Audio', 'input_device', str(self.input_device_index))
            
            # Load output device
            if config.has_option('Audio', 'output_device'):
                self.output_device_index = config.getint('Audio', 'output_device')
            else:
                # Use default output device
                default_output = self.pyaudio.get_default_output_device_info()
                self.output_device_index = default_output['index']
                config.set('Audio', 'output_device', str(self.output_device_index))
            
            # Save config
            self.client.save_config()
            
        except Exception as e:
            logger.error(f"Error loading audio device settings: {str(e)}")
            # Try to use default devices
            try:
                default_input = self.pyaudio.get_default_input_device_info()
                self.input_device_index = default_input['index']
                
                default_output = self.pyaudio.get_default_output_device_info()
                self.output_device_index = default_output['index']
            except:
                logger.error("Could not determine default audio devices")
                self.input_device_index = None
                self.output_device_index = None
    
    def save_device_settings(self):
        """Save audio device settings to configuration"""
        try:
            config = self.client.config
            
            if self.input_device_index is not None:
                config.set('Audio', 'input_device', str(self.input_device_index))
            
            if self.output_device_index is not None:
                config.set('Audio', 'output_device', str(self.output_device_index))
            
            # Save config
            self.client.save_config()
            
        except Exception as e:
            logger.error(f"Error saving audio device settings: {str(e)}")
    
    def set_input_device(self, device_index):
        """
        Set the input device
        
        Args:
            device_index: Index of the input device to use
        """
        try:
            # Check if we need to restart the audio thread
            restart = self.running
            
            # Stop if running
            if restart:
                self.stop()
            
            # Set new device
            self.input_device_index = device_index
            
            # Save settings
            self.save_device_settings()
            
            # Restart if needed
            if restart:
                self.start()
            
            logger.info(f"Input device set to: {device_index}")
            return True
            
        except Exception as e:
            logger.error(f"Error setting input device: {str(e)}")
            return False
    
    def set_output_device(self, device_index):
        """
        Set the output device
        
        Args:
            device_index: Index of the output device to use
        """
        try:
            # Check if we need to restart the audio thread
            restart = self.running
            
            # Stop if running
            if restart:
                self.stop()
            
            # Set new device
            self.output_device_index = device_index
            
            # Save settings
            self.save_device_settings()
            
            # Restart if needed
            if restart:
                self.start()
            
            logger.info(f"Output device set to: {device_index}")
            return True
            
        except Exception as e:
            logger.error(f"Error setting output device: {str(e)}")
            return False
    
    def check_virtual_audio_device(self):
        """
        Check if a virtual audio device is installed
        
        Returns:
            True if a virtual audio device is detected, False otherwise
        """
        # Look for common virtual audio device names
        virtual_device_keywords = [
            'VB-Audio', 'Virtual Cable', 'CABLE Input', 'CABLE Output',
            'Virtual Audio', 'Voicemeeter', 'VAC', 'Virtual Sound'
        ]
        
        for device in self.available_devices:
            for keyword in virtual_device_keywords:
                if keyword.lower() in device['name'].lower():
                    return True
        
        return False
    
    def install_virtual_audio_device(self):
        """
        Provide instructions for installing a virtual audio device
        
        Returns:
            Instructions message
        """
        message = (
            "To use Voice Transformer with other applications, you need to install a virtual audio device:\n\n"
            "1. Download VB-Cable from: https://vb-audio.com/Cable/\n"
            "2. Extract and run the installer as administrator\n"
            "3. Restart your computer\n"
            "4. In Voice Transformer, select 'CABLE Input' as your output device\n"
            "5. In your calling application (Zoom, Discord, etc.), select 'CABLE Output' as your microphone\n\n"
            "Would you like to open the VB-Cable download page now?"
        )
        
        return message
    
    def start(self):
        """Start audio processing thread"""
        if self.running:
            logger.warning("Audio processing already running")
            return False
        
        # Check if we have valid devices
        if self.input_device_index is None or self.output_device_index is None:
            logger.error("No valid audio devices selected")
            return False
        
        try:
            # Clear buffers
            while not self.input_buffer.empty():
                self.input_buffer.get()
            
            while not self.output_buffer.empty():
                self.output_buffer.get()
            
            # Start audio thread
            self.running = True
            self.audio_thread = threading.Thread(target=self._audio_processing_thread)
            self.audio_thread.daemon = True
            self.audio_thread.start()
            
            logger.info("Audio processing started")
            return True
            
        except Exception as e:
            logger.error(f"Error starting audio processing: {str(e)}")
            self.running = False
            return False
    
    def stop(self):
        """Stop audio processing thread"""
        if not self.running:
            return
        
        logger.info("Stopping audio processing")
        self.running = False
        
        # Wait for thread to finish
        if self.audio_thread:
            self.audio_thread.join(timeout=2.0)
        
        # Close streams
        try:
            if self.input_stream:
                self.input_stream.stop_stream()
                self.input_stream.close()
                self.input_stream = None
            
            if self.output_stream:
                self.output_stream.stop_stream()
                self.output_stream.close()
                self.output_stream = None
                
        except Exception as e:
            logger.error(f"Error closing audio streams: {str(e)}")
        
        logger.info("Audio processing stopped")
    
    def _audio_processing_thread(self):
        """Main audio processing thread"""
        try:
            # Setup input stream
            self.input_stream = self.pyaudio.open(
                format=self.format,
                channels=self.channels,
                rate=self.sample_rate,
                input=True,
                input_device_index=self.input_device_index,
                frames_per_buffer=self.chunk_size,
                stream_callback=self._input_callback
            )
            
            # Setup output stream
            self.output_stream = self.pyaudio.open(
                format=self.format,
                channels=self.channels,
                rate=self.sample_rate,
                output=True,
                output_device_index=self.output_device_index,
                frames_per_buffer=self.chunk_size,
                stream_callback=self._output_callback
            )
            
            # Start streams
            self.input_stream.start_stream()
            self.output_stream.start_stream()
            
            # Process until stopped
            while self.running:
                time.sleep(0.1)
                
                # Update UI with audio levels
                if hasattr(self.client, 'ui'):
                    self.client.ui.update_audio_levels(self.input_level, self.output_level)
            
        except Exception as e:
            logger.error(f"Error in audio processing thread: {str(e)}")
            self.running = False
    
    def _input_callback(self, in_data, frame_count, time_info, status):
        """Callback for input stream"""
        if status:
            logger.warning(f"Input stream status: {status}")
        
        try:
            # Calculate input level (simple RMS)
            audio_data = np.frombuffer(in_data, dtype=np.int16)
            rms = np.sqrt(np.mean(audio_data.astype(np.float32) ** 2))
            normalized_level = min(1.0, rms / 32768.0)
            self.input_level = normalized_level
            
            # Send to server for processing
            self.client.send_audio_to_server(in_data)
            
        except Exception as e:
            logger.error(f"Error in input callback: {str(e)}")
        
        return (in_data, pyaudio.paContinue)
    
    def _output_callback(self, in_data, frame_count, time_info, status):
        """Callback for output stream"""
        if status:
            logger.warning(f"Output stream status: {status}")
        
        try:
            # Get data from output buffer if available
            if not self.output_buffer.empty():
                data = self.output_buffer.get()
                
                # Calculate output level
                audio_data = np.frombuffer(data, dtype=np.int16)
                rms = np.sqrt(np.mean(audio_data.astype(np.float32) ** 2))
                normalized_level = min(1.0, rms / 32768.0)
                self.output_level = normalized_level
                
                return (data, pyaudio.paContinue)
            else:
                # No data available, output silence
                return (bytes(frame_count * self.channels * 2), pyaudio.paContinue)
                
        except Exception as e:
            logger.error(f"Error in output callback: {str(e)}")
            # Output silence on error
            return (bytes(frame_count * self.channels * 2), pyaudio.paContinue)
    
    def on_processed_audio(self, audio_data):
        """
        Handle processed audio data from server
        
        Args:
            audio_data: Base64 encoded or raw audio data
        """
        try:
            # Convert from base64 if needed
            if isinstance(audio_data, str):
                audio_bytes = base64.b64decode(audio_data)
            else:
                audio_bytes = audio_data
                
            # Add to output buffer if not full
            if not self.output_buffer.full():
                self.output_buffer.put(audio_bytes)
                
        except Exception as e:
            logger.error(f"Error handling processed audio: {str(e)}")
    
    def record_sample(self, duration=5, file_path=None):
        """
        Record a voice sample for cloning
        
        Args:
            duration: Recording duration in seconds
            file_path: Output file path, or None to generate one
            
        Returns:
            Path to recorded sample, or None on error
        """
        try:
            if file_path is None:
                # Generate file path in temp directory
                import tempfile
                file_path = os.path.join(
                    tempfile.gettempdir(),
                    f"voice_sample_{int(time.time())}.wav"
                )
            
            # Create a new PyAudio instance for recording
            p = pyaudio.PyAudio()
            
            # Open stream
            stream = p.open(
                format=self.format,
                channels=self.channels,
                rate=self.sample_rate,
                input=True,
                input_device_index=self.input_device_index,
                frames_per_buffer=self.chunk_size
            )
            
            logger.info(f"Recording sample for {duration} seconds...")
            
            # Start recording
            frames = []
            for i in range(0, int(self.sample_rate / self.chunk_size * duration)):
                data = stream.read(self.chunk_size)
                frames.append(data)
            
            # Stop recording
            stream.stop_stream()
            stream.close()
            p.terminate()
            
            # Save to WAV file
            wf = wave.open(file_path, 'wb')
            wf.setnchannels(self.channels)
            wf.setsampwidth(p.get_sample_size(self.format))
            wf.setframerate(self.sample_rate)
            wf.writeframes(b''.join(frames))
            wf.close()
            
            logger.info(f"Sample recorded and saved to: {file_path}")
            
            return file_path
            
        except Exception as e:
            logger.error(f"Error recording sample: {str(e)}")
            return None

    def __del__(self):
        """Clean up resources on deletion"""
        self.stop()
        
        try:
            self.pyaudio.terminate()
        except:
            pass
