# Voice Transformer

Voice Transformer is a free, open-source system for transforming your voice in real-time during calls and meetings. It provides features similar to commercial applications like Krisp.ai, allowing you to change your accent, cancel background noise, and even clone voices.

## Features

- **Noise Cancellation**: Remove background noise from your microphone and speaker audio
- **Voice Isolation**: Keep only the main speaker's voice, removing all other sounds
- **Echo Cancellation**: Detect and remove audio feedback during calls
- **Accent Conversion**: Change your accent while preserving your voice identity and emotions
- **Gender Transformation**: Make your voice sound more masculine, feminine, or neutral
- **Voice Cloning**: Upload a sample of any voice and speak using that voice in real-time
- **Local Processing**: All processing happens on your device with no data sent to the cloud
- **Application Integration**: Works with Zoom, WhatsApp, Discord, and other applications

## System Architecture

Voice Transformer consists of two main components:

1. **Server**: Processes audio using advanced machine learning models
2. **Client**: Windows application that provides a user interface and connects to applications

## Requirements

### Server
- Python 3.8 or newer
- Flask and Flask-SocketIO
- NumPy, SciPy, and LibROSA
- PyAudio

### Client
- Windows 10 or newer
- Virtual audio device (e.g., VB-Cable)

## Installation

### Server

1. Clone this repository:

```bash
git clone https://github.com/username/voice-transformer.git
cd voice-transformer
