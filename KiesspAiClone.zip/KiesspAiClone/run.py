#!/usr/bin/env python3
"""
Main entry point for the Voice Transformation Server
"""
import os
import logging
from server import app

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

if __name__ == "__main__":
    logger.info("Starting Voice Transformation Server")
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
