"""
Voice transformation module for accent conversion, gender transformation, and voice cloning
"""
import logging
import uuid
import numpy as np
import os
from models.accent_conversion import AccentConversionModel
from models.voice_cloning import VoiceCloningModel
from models.gender_transformation import GenderTransformationModel

logger = logging.getLogger(__name__)

class VoiceTransformer:
    """Handles voice transformation capabilities"""
    
    def __init__(self):
        """Initialize voice transformer with necessary models"""
        logger.info("Initializing VoiceTransformer")
        self.accent_model = AccentConversionModel()
        self.voice_cloning_model = VoiceCloningModel()
        self.gender_model = GenderTransformationModel()
        
        # Storage for voice samples
        self.voice_samples = {}
        
        # Available transformation options
        self.available_accents = ["American", "British", "Indian", "Neutral"]
        self.available_genders = ["Male", "Female", "Neutral"]
        self.available_personas = ["Normal", "Robot", "Cartoon", "Elder", "Child"]
        
        logger.info("VoiceTransformer initialized successfully")
    
    def get_available_accents(self):
        """Return the list of available accent transformations"""
        return self.available_accents
    
    def get_available_genders(self):
        """Return the list of available gender transformations"""
        return self.available_genders
    
    def get_available_personas(self):
        """Return the list of available persona transformations"""
        return self.available_personas
    
    def process_voice_sample(self, sample_id, audio_data):
        """
        Process a voice sample for cloning
        
        Args:
            sample_id: Unique identifier for the voice sample
            audio_data: Raw audio data of the voice sample
            
        Returns:
            True if successful, raises an exception otherwise
        """
        try:
            # Convert audio data to numpy array if it's bytes
            if isinstance(audio_data, bytes):
                audio_array = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
            else:
                audio_array = audio_data
            
            # Extract speaker embedding using the voice cloning model
            embedding = self.voice_cloning_model.extract_embedding(audio_array)
            
            # Store the embedding for future transformations
            self.voice_samples[sample_id] = {
                'embedding': embedding,
                'created_at': os.path.getmtime(__file__) if os.path.exists(__file__) else 0
            }
            
            logger.info(f"Voice sample {sample_id} processed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error processing voice sample: {str(e)}")
            raise
    
    def transform_voice(self, audio_data, accent=None, gender=None, voice_clone_id=None):
        """
        Apply voice transformations to audio data
        
        Args:
            audio_data: The raw audio data
            accent: Target accent (if any)
            gender: Target gender (if any)
            voice_clone_id: ID of a voice sample for cloning (if any)
            
        Returns:
            Transformed audio data
        """
        try:
            # Convert audio data to numpy array if needed
            if isinstance(audio_data, bytes):
                audio_array = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
            elif isinstance(audio_data, str):
                import base64
                decoded = base64.b64decode(audio_data)
                audio_array = np.frombuffer(decoded, dtype=np.int16).astype(np.float32) / 32768.0
            else:
                audio_array = audio_data
            
            transformed_audio = audio_array.copy()
            
            # Apply transformations in sequence
            
            # 1. Apply gender transformation if requested
            if gender and gender in self.available_genders:
                transformed_audio = self.gender_model.transform_gender(transformed_audio, gender)
            
            # 2. Apply accent conversion if requested
            if accent and accent in self.available_accents:
                transformed_audio = self.accent_model.convert_accent(transformed_audio, accent)
            
            # 3. Apply voice cloning if requested
            if voice_clone_id and voice_clone_id in self.voice_samples:
                embedding = self.voice_samples[voice_clone_id]['embedding']
                transformed_audio = self.voice_cloning_model.clone_voice(transformed_audio, embedding)
            
            # Convert back to the original format
            if isinstance(audio_data, bytes):
                transformed_audio = (transformed_audio * 32768.0).astype(np.int16).tobytes()
            elif isinstance(audio_data, str):
                import base64
                transformed_bytes = (transformed_audio * 32768.0).astype(np.int16).tobytes()
                transformed_audio = base64.b64encode(transformed_bytes).decode('utf-8')
            
            return transformed_audio
                
        except Exception as e:
            logger.error(f"Error in voice transformation: {str(e)}")
            # Return original audio in case of error
            return audio_data
